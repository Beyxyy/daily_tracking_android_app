package fr.anthonykalbe.daily_tracking;

public class ButtonInteractionManager {



//    private void action(){
      //  System.out.print("salut");
    //}
}
